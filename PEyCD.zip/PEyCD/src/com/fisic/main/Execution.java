package com.fisic.main;


import com.fisic.login.Login;

public class Execution {

	public static void main(String[] args) {

		Login L = new Login();
		L.setVisible(true);
		L.setTitle("Login");
		L.setLocationRelativeTo(null);

	}

}
